import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Pizza, Truck, Clock, Star, Phone, MapPin, Instagram, Facebook } from "lucide-react";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    title: "Pizza Formaggio | A Melhor de Porto Alegre",
    meta: [
      { name: "description", content: "A Pizza Formaggio oferece a melhor pizza da região de Porto Alegre. Ingredientes selecionados e entrega rápida para você." },
      { property: "og:title", content: "Pizza Formaggio | A Melhor de Porto Alegre" },
      { property: "og:description", content: "Peça agora a melhor pizza da região. Sabor incomparável e entrega rápida!" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#fcfbf8] font-sans selection:bg-primary selection:text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 ${scrolled ? "bg-white/80 backdrop-blur-md border-b border-border shadow-sm" : "bg-transparent"}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img 
              src="https://i.ibb.co/MDFBCVLy/file-0000000060a0820e859fd76c6ec4b8a1.png" 
              alt="Logo Pizza Formaggio" 
              className="w-10 h-10 rounded-full object-contain"
            />
            <span className="text-2xl font-bold tracking-tight text-foreground">Pizza Formaggio</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#hero" className="hover:text-primary transition-colors">Início</a>
            <a href="#features" className="hover:text-primary transition-colors">Diferenciais</a>
            <a href="#menu" className="hover:text-primary transition-colors">Cardápio</a>
            <a href="#faq" className="hover:text-primary transition-colors">FAQ</a>
          </div>
          <Button className="rounded-full px-6 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all active:scale-95">
            Pedir Agora
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6">
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 px-4 py-1.5 rounded-full text-sm font-semibold animate-in fade-in slide-in-from-bottom-4 duration-500">
            A melhor pizza da região
          </Badge>
          <h1 className="text-5xl md:text-8xl font-black tracking-tighter text-foreground mb-6 max-w-4xl mx-auto leading-[0.9] animate-in fade-in slide-in-from-bottom-8 duration-700">
            EXPERIMENTE A <span className="text-primary italic">AUTÊNTICA</span> ARTE GAÚCHA.
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-12 duration-1000">
            Na Pizza Formaggio, cada fatia é uma explosão de sabor com ingredientes frescos e massa artesanal. A melhor experiência de Porto Alegre.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-16 duration-1000">
            <Button size="lg" className="w-full md:w-auto rounded-full px-10 h-14 text-lg font-bold bg-primary hover:bg-primary/90 shadow-2xl shadow-primary/30 active:scale-95 transition-all">
              Ver Cardápio Completo
            </Button>
            <Button variant="outline" size="lg" asChild className="w-full md:w-auto rounded-full px-10 h-14 text-lg font-bold border-2 hover:bg-secondary/10 transition-all active:scale-95">
              <a href="https://maps.app.goo.gl/wiZ311bcyonnydCM9?g_st=ac" target="_blank" rel="noopener noreferrer">
                Nossa Localização
              </a>
            </Button>
          </div>
        </div>

        {/* Hero Background Elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl aspect-square bg-primary/5 blur-3xl rounded-full -z-0" />
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">NOSSA PIZZARIA</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Conheça um pouco do nosso ambiente e o que preparamos para você.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-lg hover:scale-[1.02] transition-transform duration-500">
              <img src="https://i.ibb.co/3mBW0FFG/image.png" alt="Pizzaria Interior 1" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-lg hover:scale-[1.02] transition-transform duration-500 mt-8">
              <img src="https://i.ibb.co/GvsnbpB5/image.png" alt="Pizzaria Interior 2" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-lg hover:scale-[1.02] transition-transform duration-500">
              <img src="https://i.ibb.co/tw6sgz7C/image.png" alt="Pizzaria Interior 3" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-lg hover:scale-[1.02] transition-transform duration-500 mt-8">
              <img src="https://i.ibb.co/m5t7JK4f/image.png" alt="Pizzaria Interior 4" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Bento Grid Features */}
      <section id="features" className="py-24 px-6 bg-secondary/5 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">POR QUE SOMOS OS MELHORES?</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Excelência em cada detalhe, do preparo à entrega na sua porta.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Bento Item 1 */}
            <Card className="md:col-span-2 group overflow-hidden border-none bg-secondary/5 hover:bg-secondary/10 transition-all duration-500 rounded-3xl">
              <CardContent className="p-8 md:p-12 flex flex-col md:flex-row items-center gap-8">
                <div className="flex-1 text-center md:text-left">
                  <Badge className="bg-primary text-white mb-4">Ingredientes Premium</Badge>
                  <CardTitle className="text-3xl md:text-4xl font-black mb-4">QUALIDADE QUE VOCÊ SENTE.</CardTitle>
                  <p className="text-muted-foreground text-lg">Usamos apenas tomates italianos selecionados e mussarela de búfala fresca em nossas receitas exclusivas.</p>
                </div>
                <div className="w-full md:w-1/2 aspect-video bg-white/40 backdrop-blur-xl rounded-2xl border border-white/20 shadow-lg flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                  <Star className="w-20 h-20 text-primary animate-pulse" />
                </div>
              </CardContent>
            </Card>

            {/* Bento Item 2 */}
            <Card className="overflow-hidden border-none bg-primary/5 hover:bg-primary/10 transition-all duration-500 rounded-3xl">
              <CardContent className="p-8 flex flex-col items-center text-center justify-center h-full">
                <div className="bg-white p-4 rounded-2xl shadow-xl shadow-primary/10 mb-6">
                  <Truck className="w-12 h-12 text-primary" />
                </div>
                <CardTitle className="text-2xl font-black mb-2">ENTREGA FLASH</CardTitle>
                <p className="text-muted-foreground text-sm uppercase font-bold tracking-widest mb-4 text-primary">Na ZS/ZL em 30 min</p>
                <p className="text-muted-foreground">Sua pizza chega quentinha e crocante, como se tivesse acabado de sair do forno.</p>
              </CardContent>
            </Card>

            {/* Bento Item 3 */}
            <Card className="overflow-hidden border-none bg-black text-white hover:bg-black/90 transition-all duration-500 rounded-3xl">
              <CardContent className="p-8 flex flex-col items-center text-center justify-center h-full">
                <div className="bg-primary p-4 rounded-2xl shadow-xl shadow-primary/20 mb-6">
                  <Clock className="w-12 h-12 text-black" />
                </div>
                <CardTitle className="text-2xl font-black mb-2">ABERTO TODOS OS DIAS</CardTitle>
                <p className="text-muted-foreground">Fome na madrugada? Estamos aqui para te salvar todos os dias das 18:30 às 23:30.</p>
              </CardContent>
            </Card>

            {/* Bento Item 4 */}
            <Card className="md:col-span-2 group overflow-hidden border-none bg-white shadow-2xl shadow-black/5 hover:shadow-primary/5 transition-all duration-500 rounded-3xl">
              <CardContent className="p-8 md:p-12 flex flex-col-reverse md:flex-row items-center gap-8">
                <div className="w-full md:w-1/2 aspect-video bg-primary/10 rounded-2xl border border-primary/5 shadow-inner flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                  <Pizza className="w-20 h-20 text-primary" />
                </div>
                <div className="flex-1 text-center md:text-right">
                  <Badge className="bg-secondary text-white mb-4">Receita Original</Badge>
                  <CardTitle className="text-3xl md:text-4xl font-black mb-4">MASSA DE LONGA FERMENTAÇÃO.</CardTitle>
                  <p className="text-muted-foreground text-lg">Massa leve, aerada e de fácil digestão. O segredo está na paciência e no amor ao preparo.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Menu Section / Pricing Table */}
      <section id="menu" className="py-24 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h2 className="text-3xl md:text-6xl font-black tracking-tight mb-4 leading-none">NOSSO CARDÁPIO.</h2>
              <p className="text-muted-foreground text-lg">Os clássicos que conquistaram Porto Alegre.</p>
            </div>
            <div className="flex items-center gap-4 text-sm font-bold bg-secondary/5 p-2 rounded-full border border-secondary/10">
              <button className="bg-white px-6 py-2 rounded-full shadow-sm">Tradicionais</button>
              <button className="px-6 py-2 text-muted-foreground hover:text-foreground">Especiais</button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {menuItems.map((item, index) => (
              <Card key={index} className="rounded-3xl border-none bg-white shadow-xl hover:shadow-2xl transition-all duration-500 group">
                <div className="aspect-square bg-muted relative overflow-hidden rounded-t-3xl">
                  <div className="absolute inset-0 bg-primary/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10">
                    <Button className="rounded-full bg-white text-black hover:bg-white/90">Ver Detalhes</Button>
                  </div>
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-4">
                    <CardTitle className="text-2xl font-black">{item.name}</CardTitle>
                    <span className="text-primary font-black text-xl">R$ {item.price}</span>
                  </div>
                  <p className="text-muted-foreground mb-6 line-clamp-2">{item.description}</p>
                  <Button className="w-full rounded-2xl h-12 font-bold bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/10 transition-all active:scale-95">
                    Adicionar ao Pedido
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="mt-20 max-w-4xl mx-auto rounded-3xl overflow-hidden shadow-2xl">
            <img 
              src="https://i.ibb.co/673N8zXw/file-00000000a31c820ea5a60442e7486257.png" 
              alt="Cardápio Completo" 
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Monthly Pizzas Section */}
      <section className="py-24 px-6 bg-secondary/5">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">PIZZAS DO MÊS</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Sabores exclusivos selecionados para cada mês do ano.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {monthlyPizzas.map((item, index) => (
              <Card key={index} className="rounded-3xl border-none bg-white shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden group">
                <div className="aspect-video relative overflow-hidden">
                  <div className="absolute top-4 left-4 z-20">
                    <Badge className="bg-primary text-white font-bold px-4 py-1 rounded-full shadow-lg">
                      {item.month}
                    </Badge>
                  </div>
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <CardContent className="p-8 text-center">
                  <CardTitle className="text-2xl font-black mb-2">{item.name}</CardTitle>
                  <p className="text-primary font-bold text-lg">{item.info}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-24 px-6 bg-secondary/5">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4">FAQ</Badge>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">DÚVIDAS FREQUENTES.</h2>
            <p className="text-muted-foreground">Tudo o que você precisa saber antes de pedir a sua Pizza Formaggio.</p>
          </div>
          
          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqItems.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-none bg-white rounded-2xl px-6 shadow-sm">
                <AccordionTrigger className="text-lg font-bold py-6 hover:no-underline hover:text-primary transition-colors">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base pb-6 leading-relaxed">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white pt-20 pb-10 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
            <img 
                src="https://i.ibb.co/MDFBCVLy/file-0000000060a0820e859fd76c6ec4b8a1.png" 
                alt="Logo Pizza Formaggio" 
                className="w-12 h-12 rounded-full object-contain"
              />
              <span className="text-3xl font-black tracking-tighter">Pizza Formaggio</span>
            </div>
            <p className="text-muted-foreground max-w-sm text-lg leading-relaxed mb-8">
              Levando o melhor da tradição gaúcha com a agilidade que a vida moderna exige. A melhor pizzaria de Porto Alegre.
            </p>
            <div className="flex gap-4">
              <a href="https://www.instagram.com/formaggio.pizzaria?igsh=MTRwd3ZpZjV3YW90MQ==" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://www.facebook.com/profile.php?id=100063537640540" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-all duration-300">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6">HORÁRIOS</h3>
            <ul className="space-y-4 text-muted-foreground font-medium">
              <li className="flex justify-between"><span>Todos os dias</span> <span>18:30 - 23:30</span></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">CONTATO</h3>
            <ul className="space-y-4 text-muted-foreground font-medium">
              <li className="flex items-center gap-3"><Phone className="w-5 h-5 text-primary" /> (51) 99397-7900</li>
               <li className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-primary" /> 
                <a href="https://maps.app.goo.gl/wiZ311bcyonnydCM9?g_st=ac" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                  Porto Alegre - RS
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 text-center text-sm text-muted-foreground">
          © 2026 Pizza Formaggio. Todos os direitos reservados.
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a 
        href="https://wa.me/5551993977900" 

        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 z-[100] bg-[#25D366] text-white p-4 rounded-full shadow-2xl shadow-green-500/30 hover:scale-110 active:scale-95 transition-all duration-300 group"
      >
        <div className="absolute right-full mr-4 bg-white text-black px-4 py-2 rounded-xl text-sm font-bold shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
          Peça pelo WhatsApp!
        </div>
        <Phone className="w-8 h-8 fill-current" />
      </a>
    </div>
  );
}

const menuItems = [
  {
    name: "Margherita Tradicional",
    price: "49,90",
    description: "Mussarela de búfala, tomate cereja, manjericão fresco e azeite extra virgem sobre nossa massa artesanal.",
    image: "https://i.ibb.co/1YNq1MD2/20220211142347-margherita-9920-0ff14530-9718-49e3-b13a-e726d7e9e119.jpg",
  },
  {
    name: "Pepperoni Supremo",
    price: "54,90",
    description: "Fatias crocantes de pepperoni premium, mussarela especial e um toque de orégano fresco.",
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?q=80&w=1780&auto=format&fit=crop",
  },
  {
    name: "Quattro Formaggi",
    price: "58,90",
    description: "O equilíbrio perfeito entre Mussarela, Gorgonzola, Parmesão e Catupiry original.",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
  },
];

const monthlyPizzas = [
  {
    month: "Abril",
    name: "Peito de Peru",
    info: "Sabor sem custo adicional.",
    image: "https://i.ibb.co/wXbJ7q1/images.jpg",
  },
  {
    month: "Abril",
    name: "Torta de Maracujá",
    info: "Sabor sem custo adicional.",
    image: "https://i.ibb.co/TBg5q8ZW/delicia-maracuja-1.jpg",
  },
  {
    month: "Maio",
    name: "Calabresa Spicy",
    info: "Sabor sem custo adicional.",
    image: "https://i.ibb.co/vCQ6D955/images-3.jpg",
  },
  {
    month: "Maio",
    name: "BanaNut",
    info: "Sabor sem custo adicional.",
    image: "https://i.ibb.co/KjY87zN5/images-2.jpg",
  },
  {
    month: "Junho",
    name: "5 Queijos",
    info: "¼ + R$ 4,00 · ⅓ + R$ 5,00 · ½ + R$ 8,00.",
    image: "https://i.ibb.co/Q712gmGT/image.png",
  },
  {
    month: "Junho",
    name: "Pistache",
    info: "¼ + R$ 4,00 · ⅓ + R$ 5,00 · ½ + R$ 8,00.",
    image: "https://i.ibb.co/TD5WbJbq/image.png",
  },
];

const faqItems = [
  {
    question: "Qual o tempo médio de entrega em Porto Alegre?",
    answer: "Trabalhamos com uma logística otimizada para a região ZS/ZL. O tempo médio de entrega é de 30 a 45 minutos, garantindo que seu pedido chegue na temperatura perfeita.",
  },
  {
    question: "Vocês trabalham com massa sem glúten?",
    answer: "No momento trabalhamos exclusivamente com nossa massa tradicional de longa fermentação, que contém glúten. Porém, ela é muito mais leve que as massas comuns devido ao processo de 48h de maturação.",
  },
  {
    question: "Posso personalizar os ingredientes da minha pizza?",
    answer: "Com certeza! Você pode adicionar ou remover ingredientes conforme seu gosto. No nosso sistema de pedidos online, você tem total liberdade para criar sua combinação favorita.",
  },
  {
    question: "Quais são as formas de pagamento aceitas?",
    answer: "Aceitamos todos os cartões de crédito e débito, PIX, e também pagamentos em dinheiro na entrega. Para pedidos via WhatsApp ou site, o PIX é a forma mais rápida de processamento.",
  },
];