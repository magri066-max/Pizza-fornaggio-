# Plano de Implementação: Landing Page Pizzaria Formaggio

Construção de uma landing page de alta conversão para a **Pizzaria Formaggio**, utilizando um estilo estético Apple/Glassmorphism, com foco em performance e SEO.

## Design System & Identidade Visual
- **Paleta de Cores:**
  - Principal: `#f59e0b` (Laranja/Âmbar) para CTAs e elementos ativos.
  - Secundária: `#2563eb` (Azul Royal) para contrastes.
  - Fundo: Estilo Glassmorphism (efeitos de desfoque e transparência).
- **Tipografia:** Inter ou Outfit (fontes sans-serif modernas).
- **Estética:** Bordas muito arredondadas, sombras suaves, espaçamentos generosos e linhas limpas.

## Estrutura da Página (`src/routes/index.tsx`)
1.  **Hero Section:** Título impactante ("A melhor da região"), imagem de alta qualidade e CTA principal ("Pedir Agora").
2.  **Bento Grid (Funcionalidades):** Destaques como ingredientes frescos, entrega rápida e receitas tradicionais.
3.  **Tabela de Preços Dinâmica:** Listagem das pizzas mais populares com preços e descrições.
4.  **FAQ com Acordeão:** Perguntas frequentes sobre entregas, horários e formas de pagamento.
5.  **Rodapé:** Informações de contato e links sociais.

## Integrações
- **WhatsApp API:** Botão flutuante para contato direto.
- **Ícones:** Lucide React para consistência visual.

## Detalhes Técnicos
- **Framework:** TanStack Start v1 (React 19).
- **Estilização:** Tailwind CSS v4.
- **Animações:** Framer Motion ou Tailwind transitions (nível intermediário).
- **SEO:** Metadados específicos para "Pizzaria Formaggio" no Centro.
- **Responsividade:** Mobile-first absoluto.

## Próximos Passos
1. Atualizar o `src/styles.css` com as variáveis de cores solicitadas.
2. Criar a estrutura principal no `src/routes/index.tsx`.
3. Implementar os componentes específicos (Hero, Bento Grid, Pricing, FAQ).
4. Adicionar o botão flutuante de WhatsApp.
